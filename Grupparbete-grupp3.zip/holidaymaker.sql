--
-- File generated with SQLiteStudio v3.3.3 on ons jan. 12 12:16:01 2022
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: facility
CREATE TABLE facility (Hotel_Facilities_ID INTEGER REFERENCES hotel_facilities (Hotel_Facilities_ID), Facility_Name VARCHAR (255), Hotel_ID INTEGER REFERENCES hotel (Hotel_ID));
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (1, 'Rooftop Pool', 1);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (3, 'Nord Restaurant', 1);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (2, 'Tower Nightclub', 2);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (4, 'Treasure Island', 2);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (3, 'Heaven 23', 2);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (1, 'W Pool', 4);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (4, 'Bamse club', 4);
INSERT INTO facility (Hotel_Facilities_ID, Facility_Name, Hotel_ID) VALUES (3, 'The Season Suite', 5);

-- Table: guest
CREATE TABLE guest (First_Name VARCHAR (255), Last_Name VARCHAR (255), Phone_Number VARCHAR (255), Email_Adress VARCHAR (255), Date_Of_Birth VARCHAR (255), Guest_ID INTEGER PRIMARY KEY NOT NULL, Reservation_ID INTEGER REFERENCES reservation);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Jeanna', 'Gerriet', '+7 650 787 9739', 'jgerriet0@engadget.com', '2008-09-06', 1, 3);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Marya', 'Medland', '+370 963 522 2993', 'mmedland1@dyndns.org', '1991-01-30', 2, 1);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Deerdre', 'Reader', '+257 696 196 4398', 'dreader2@columbia.edu', '1936-08-06', 3, 2);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kane', 'Renzullo', '+63 431 814 5923', 'krenzullo3@google.fr', '1979-09-09', 4, 2);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Cheri', 'Jacobs', '+509 307 770 2113', 'cjacobs4@ucla.edu', '1964-05-05', 5, 3);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Corrina', 'Godrich', '+86 370 521 4038', 'cgodrich5@biblegateway.com', '2000-08-24', 6, 4);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kayla', 'Blethyn', '+63 915 258 7423', 'kblethyn6@odnoklassniki.ru', '1957-10-05', 7, 5);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kylynn', 'Stiling', '+51 815 139 5956', 'kstiling7@ehow.com', '1969-02-07', 8, 5);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gwenore', 'Torritti', '+62 112 989 8992', 'gtorritti8@lycos.com', '1999-12-04', 9, 5);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Laural', 'Morbey', '+86 273 394 5625', 'lmorbey9@sciencedirect.com', '1971-08-09', 10, 5);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Desi', 'Chipps', '+234 772 728 2470', 'dchippsa@webeden.co.uk', '1944-08-07', 11, 6);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Eb', 'Thumnel', '+66 884 154 2726', 'ethumnelb@sciencedirect.com', '1937-03-01', 12, 6);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Elbert', 'Trinbey', '+51 448 365 8086', 'etrinbeyc@twitpic.com', '1985-11-18', 13, 7);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Austina', 'Baalham', '+92 224 855 1139', 'abaalhamd@tinypic.com', '1986-03-03', 14, 7);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Etheline', 'Aykroyd', '+86 992 788 6768', 'eaykroyde@cdc.gov', '1975-05-06', 15, 7);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Reta', 'Paler', '+380 214 613 2202', 'rpalerf@tuttocitta.it', '1996-12-10', 16, 8);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lorry', 'Cheney', '+505 559 370 6385', 'lcheneyg@paypal.com', '1985-12-24', 17, 9);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Engracia', 'Broun', '+62 171 862 5272', 'ebrounh@cloudflare.com', '2019-03-06', 18, 10);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Klarrisa', 'Bezzant', '+685 895 122 9483', 'kbezzanti@jalbum.net', '1951-07-27', 19, 10);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Bengt', 'Arr', '+86 502 558 9945', 'barrj@yellowpages.com', '1949-06-09', 20, 10);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ferd', 'Bettles', '+86 935 276 2820', 'fbettlesk@yahoo.co.jp', '2017-08-27', 21, 10);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Maryann', 'Patman', '+7 878 561 0113', 'mpatmanl@sciencedaily.com', '2005-12-19', 22, 13);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gilligan', 'Twamley', '+86 301 646 7908', 'gtwamleym@ted.com', '2010-02-16', 23, 12);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Tiffie', 'Neaves', '+351 805 576 7862', 'tneavesn@google.es', '1940-03-24', 24, 11);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Collie', 'Morde', '+55 597 686 7850', 'cmordeo@facebook.com', '1964-04-03', 25, 12);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Olympia', 'O''Flaverty', '+351 768 177 2968', 'ooflavertyp@ebay.co.uk', '1935-09-04', 26, 13);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Valle', 'Gensavage', '+63 521 427 4928', 'vgensavageq@businessweek.com', '1959-10-23', 27, 14);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Caprice', 'Nardrup', '+57 667 929 7831', 'cnardrupr@blogger.com', '1980-05-13', 28, 15);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Giselbert', 'Rayer', '+86 496 720 4259', 'grayers@squidoo.com', '1960-07-19', 29, 16);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gunter', 'Nijs', '+353 231 788 4418', 'gnijst@flickr.com', '2013-03-25', 30, 15);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Hasheem', 'Strutt', '+81 986 958 6642', 'hstruttu@amazonaws.com', '1980-03-30', 31, 16);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Valentine', 'McGonnell', '+86 875 357 8938', 'vmcgonnellv@google.cn', '1976-10-25', 32, 17);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Wallie', 'Swedeland', '+1 587 500 1233', 'wswedelandw@google.ca', '2002-02-24', 33, 17);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Octavius', 'Kilfether', '+66 818 353 9867', 'okilfetherx@theatlantic.com', '1978-07-17', 34, 17);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kelley', 'Caccavari', '+44 208 907 5443', 'kcaccavariy@biblegateway.com', '2006-03-08', 35, 17);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Hammad', 'McSkin', '+60 229 713 4871', 'hmcskinz@cafepress.com', '1992-02-14', 36, 18);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Rolfe', 'Heindrick', '+389 203 224 8543', 'rheindrick10@nbcnews.com', '1956-11-23', 37, 18);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kliment', 'Tarburn', '+44 841 167 8649', 'ktarburn11@yale.edu', '1933-11-20', 38, 18);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lou', 'Drewe', '+33 561 117 5739', 'ldrewe12@vimeo.com', '1984-08-14', 39, 19);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Rockwell', 'Cheesworth', '+355 508 369 7801', 'rcheesworth13@bloomberg.com', '1961-08-31', 40, 20);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Estele', 'Jeakins', '+56 705 290 2798', 'ejeakins14@livejournal.com', '1977-10-09', 41, 20);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Glynis', 'Armal', '+46 587 463 3094', 'garmal15@pagesperso-orange.fr', '2017-08-21', 42, 22);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Muffin', 'Wrate', '+381 950 844 9161', 'mwrate16@macromedia.com', '2008-04-10', 43, 21);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ward', 'Tofts', '+30 298 197 4388', 'wtofts17@dropbox.com', '1980-11-28', 44, 21);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Allayne', 'Jaxon', '+380 750 403 4421', 'ajaxon18@xing.com', '2020-09-11', 45, 22);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Marcello', 'Campa', '+62 189 913 8845', 'mcampa19@tumblr.com', '1978-11-02', 46, 22);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Anthea', 'Bigly', '+55 136 150 6956', 'abigly1a@bizjournals.com', '1952-05-14', 47, 23);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Tally', 'Pate', '+86 202 661 0649', 'tpate1b@chron.com', '1962-02-16', 48, 24);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Glory', 'Dreye', '+62 956 410 5615', 'gdreye1c@weather.com', '1994-03-30', 49, 24);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kirsten', 'Dragge', '+46 643 205 1846', 'kdragge1d@gizmodo.com', '1992-04-29', 50, 24);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Sax', 'Tolland', '156-542-3249', 'stolland0@livejournal.com', '2007-04-26', 51, 25);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ilaire', 'Bloan', '945-590-8188', 'ibloan1@timesonline.co.uk', '2020-11-23', 52, 28);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ulrica', 'Colston', '270-990-6462', 'ucolston2@tmall.com', '1937-08-25', 53, 25);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kora', 'Allcroft', '180-406-4355', 'kallcroft3@princeton.edu', '2013-12-26', 54, 27);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ursala', 'Priditt', '442-397-3751', 'upriditt4@myspace.com', '1963-07-03', 55, 26);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kendell', 'Thome', '582-743-9006', 'kthome5@telegraph.co.uk', '1972-08-27', 56, 27);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Rosalyn', 'Attenborrow', '919-735-8180', 'rattenborrow6@naver.com', '1965-11-07', 57, 28);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Leeanne', 'Guarin', '499-924-0624', 'lguarin7@multiply.com', '1983-12-15', 58, 29);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Robb', 'Frayn', '437-821-9778', 'rfrayn8@t-online.de', '1979-05-27', 59, 29);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Bennett', 'Liston', '223-271-8362', 'bliston9@sun.com', '1939-02-03', 60, 29);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Fran', 'Laurant', '897-632-8256', 'flauranta@foxnews.com', '2000-11-28', 61, 29);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kitty', 'Pollicott', '583-784-0168', 'kpollicottb@amazon.co.uk', '1953-02-05', 62, 30);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Oren', 'Yeates', '993-946-3344', 'oyeatesc@umn.edu', '1957-04-24', 63, 30);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lilas', 'Sloam', '620-381-1367', 'lsloamd@jalbum.net', '1991-05-30', 64, 31);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gloriana', 'Kaes', '781-658-1505', 'gkaese@examiner.com', '2003-02-28', 65, 32);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Barris', 'Wheal', '940-482-2097', 'bwhealf@marriott.com', '1998-12-24', 66, 32);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Felizio', 'Jozefczak', '882-585-3298', 'fjozefczakg@sourceforge.net', '1961-11-25', 67, 32);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Joshua', 'Kristof', '824-828-6953', 'jkristofh@webnode.com', '1977-06-04', 68, 33);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gage', 'Varnes', '568-939-5996', 'gvarnesi@1und1.de', '1938-04-23', 69, 33);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Iolande', 'Limming', '235-112-8878', 'ilimmingj@fema.gov', '1956-10-07', 70, 34);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Reina', 'Weare', '243-833-2705', 'rwearek@webs.com', '1998-04-25', 71, 34);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Jeane', 'Gidney', '555-916-7148', 'jgidneyl@surveymonkey.com', '1948-05-17', 72, 34);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Trish', 'Hinkensen', '769-376-8357', 'thinkensenm@blogtalkradio.com', '1976-08-21', 73, 34);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lucius', 'Inglesfield', '331-160-4495', 'linglesfieldn@webmd.com', '1975-11-01', 74, 34);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Danell', 'Brisco', '188-345-8061', 'dbriscoo@privacy.gov.au', '2011-09-22', 75, 35);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Mareah', 'Jerromes', '992-776-5418', 'mjerromesp@last.fm', '1948-07-11', 76, 35);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lorry', 'Brisco', '392-976-9422', 'lbriscoq@amazon.de', '1984-05-20', 77, 36);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Justen', 'Duran', '680-922-3512', 'jduranr@linkedin.com', '2016-07-20', 78, 36);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Pail', 'Wetheril', '344-394-7250', 'pwetherils@clickbank.net', '1989-01-02', 79, 36);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Juline', 'Luby', '724-927-8572', 'jlubyt@usnews.com', '1994-03-10', 80, 36);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Juliann', 'Heibl', '667-427-3789', 'jheiblu@google.fr', '1994-11-02', 81, 37);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Trish', 'Triggle', '465-368-6305', 'ttrigglev@geocities.com', '1940-05-17', 82, 37);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Bordy', 'Burnside', '791-945-2725', 'bburnsidew@drupal.org', '1945-10-01', 83, 38);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Else', 'Wickson', '470-364-7088', 'ewicksonx@ucoz.com', '1965-09-28', 84, 38);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Nonie', 'Matskevich', '958-384-9484', 'nmatskevichy@nyu.edu', '2004-10-21', 85, 40);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Elyn', 'Levey', '199-672-2237', 'eleveyz@bbc.co.uk', '1944-10-08', 86, 39);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Sampson', 'Whapples', '472-301-2342', 'swhapples10@china.com.cn', '2020-10-05', 87, 41);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Benni', 'Barents', '949-498-7347', 'bbarents11@google.co.uk', '1971-10-26', 88, 40);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('William', 'Gribben', '150-410-2795', 'wgribben12@marketwatch.com', '1992-05-13', 89, 41);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Darnall', 'Fallens', '700-516-2543', 'dfallens13@pagesperso-orange.fr', '1968-04-11', 90, 41);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Birdie', 'Rackstraw', '903-656-2118', 'brackstraw14@bizjournals.com', '1958-03-09', 91, 42);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Ilario', 'Lammert', '399-245-3117', 'ilammert15@zimbio.com', '1995-05-20', 92, 43);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Kiele', 'Keford', '929-556-2012', 'kkeford16@tinypic.com', '1998-02-08', 93, 43);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Norina', 'Boller', '548-632-5808', 'nboller17@digg.com', '1971-04-24', 94, 44);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Garrek', 'Sprowell', '276-131-9057', 'gsprowell18@about.com', '1995-04-11', 95, 44);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Elyse', 'Dundendale', '967-306-0067', 'edundendale19@state.tx.us', '1993-10-08', 96, 45);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Melva', 'Stanning', '721-931-2408', 'mstanning1a@devhub.com', '2015-01-25', 97, 46);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Esra', 'Daingerfield', '716-298-6152', 'edaingerfield1b@devhub.com', '1978-03-16', 98, 46);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Gawen', 'Bartaloni', '470-395-3586', 'gbartaloni1c@geocities.com', '1980-01-20', 99, 47);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Philly', 'Rannigan', '483-817-2593', 'prannigan1d@marriott.com', '1942-09-13', 100, 48);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Mildrid', 'Kimmitt', '811-323-4813', 'mkimmitt0@fastcompany.com', '2021-04-12', 101, 50);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Derry', 'Pursglove', '249-987-8925', 'dpursglove1@storify.com', '1970-02-13', 102, 49);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Lucian', 'Sirmond', '704-993-1376', 'lsirmond2@newsvine.com', '1968-09-27', 103, 50);
INSERT INTO guest (First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth, Guest_ID, Reservation_ID) VALUES ('Leonanie', 'Buckleigh', '235-692-1299', 'lbuckleigh3@quantcast.com', '1973-02-01', 104, 50);

-- Table: hotel
CREATE TABLE hotel (Hotel_Name VARCHAR (255), Hotel_ID INTEGER PRIMARY KEY NOT NULL, Hotel_Address VARCHAR (255), Hotel_Phone_Number VARCHAR (255), Hotel_City VARCHAR (255), Hotel_Country VARCHAR (255), Hotel_Email VARCHAR (255), Hotel_Zip_Code VARCHAR (255));
INSERT INTO hotel (Hotel_Name, Hotel_ID, Hotel_Address, Hotel_Phone_Number, Hotel_City, Hotel_Country, Hotel_Email, Hotel_Zip_Code) VALUES ('Clarion Hotel Post', 1, 'Drottningtorget 10', '+4631619000', 'Gothenburg', 'Sweden', 'post@test.com', '41103');
INSERT INTO hotel (Hotel_Name, Hotel_ID, Hotel_Address, Hotel_Phone_Number, Hotel_City, Hotel_Country, Hotel_Email, Hotel_Zip_Code) VALUES ('Gothia Towers', 2, 'M‰ssans Gata 24', '+460317508800', 'Gothenburg', 'Sweden', 'gothia@test.com', '41251');
INSERT INTO hotel (Hotel_Name, Hotel_ID, Hotel_Address, Hotel_Phone_Number, Hotel_City, Hotel_Country, Hotel_Email, Hotel_Zip_Code) VALUES ('The Savoy Hotel', 3, 'Strand', '+442078364343', 'London', 'United Kingdom', 'savoy@test.com', 'WC2R 0EZ');
INSERT INTO hotel (Hotel_Name, Hotel_ID, Hotel_Address, Hotel_Phone_Number, Hotel_City, Hotel_Country, Hotel_Email, Hotel_Zip_Code) VALUES ('W Barcelona', 4, 'PlaÁa Rosa Del Vents 1', '+34932952800', 'Barcelona', 'Spain', 'w@test.com', '08039');
INSERT INTO hotel (Hotel_Name, Hotel_ID, Hotel_Address, Hotel_Phone_Number, Hotel_City, Hotel_Country, Hotel_Email, Hotel_Zip_Code) VALUES ('Four Seasons Hotel', 5, '57 East 57th Street', '+1 (855) 249-5811', 'New York', 'United States', 'fourseasons@test.com', '10022');

-- Table: hotel_facilities
CREATE TABLE hotel_facilities (Hotel_Facitilies_Name VARCHAR (255) NOT NULL, Hotel_Facilities_ID INTEGER PRIMARY KEY NOT NULL);
INSERT INTO hotel_facilities (Hotel_Facitilies_Name, Hotel_Facilities_ID) VALUES ('Pool', 1);
INSERT INTO hotel_facilities (Hotel_Facitilies_Name, Hotel_Facilities_ID) VALUES ('Evening entertainment', 2);
INSERT INTO hotel_facilities (Hotel_Facitilies_Name, Hotel_Facilities_ID) VALUES ('Restaurant', 3);
INSERT INTO hotel_facilities (Hotel_Facitilies_Name, Hotel_Facilities_ID) VALUES ('Childrens Club', 4);

-- Table: reservation
CREATE TABLE reservation (Reservation_ID INTEGER PRIMARY KEY NOT NULL, Check_In VARCHAR (255), Check_Out VARCHAR (255), Room_ID INTEGER REFERENCES room (Room_ID), Hotel_ID INTEGER REFERENCES hotel (Hotel_ID), Number_Of_Guests INTEGER (255), Guest_ID INTEGER REFERENCES guest (Guest_ID), Room_Number INTEGER);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (1, '2022-07-11', '2022-07-20', 1, 5, 1, 2, 5101);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (2, '2022-06-24', '2022-07-12', 2, 2, 2, 3, 2204);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (3, '2022-07-29', '2022-07-30', 2, 5, 2, 5, 1103);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (4, '2022-07-02', '2022-07-16', 1, 4, 1, 6, 4100);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (5, '2022-07-02', '2022-07-21', 3, 2, 4, 7, 2301);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (6, '2022-07-23', '2022-07-26', 2, 2, 2, 11, 2203);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (7, '2022-07-14', '2022-07-16', 3, 2, 3, 13, 3206);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (8, '2022-06-26', '2022-07-18', 1, 1, 1, 16, 1102);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (9, '2022-06-26', '2022-07-26', 1, 2, 1, 17, 2103);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (10, '2022-07-10', '2022-07-20', 3, 5, 4, 19, 5302);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (11, '2022-07-13', '2022-07-14', 1, 2, 1, 24, 2104);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (12, '2022-07-18', '2022-07-26', 2, 4, 2, 25, 4209);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (13, '2022-06-01', '2022-06-05', 2, 5, 2, 26, 5207);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (14, '2022-06-05', '2022-06-25', 1, 5, 1, 27, 5104);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (15, '2022-06-12', '2022-06-14', 2, 2, 2, 28, 2204);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (16, '2022-06-04', '2022-06-10', 3, 1, 2, 29, 1301);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (17, '2022-06-01', '2022-06-04', 3, 4, 4, 32, 4307);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (18, '2022-07-15', '2022-07-18', 3, 3, 3, 36, 3302);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (19, '2022-07-16', '2022-07-18', 1, 5, 1, 39, 5103);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (20, '2022-07-05', '2022-07-10', 2, 4, 2, 40, 4203);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (21, '2022-06-03', '2022-06-10', 2, 3, 2, 44, 3206);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (22, '2022-06-06', '2022-06-15', 3, 2, 3, 46, 2303);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (23, '2022-06-06', '2022-06-15', 1, 2, 1, 47, 2105);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (24, '2022-06-03', '2022-06-18', 3, 1, 3, 48, 1304);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (25, '2022-06-04', '2022-06-09', 2, 2, 2, 53, 2200);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (26, '2022-06-30', '2022-07-07', 1, 2, 1, 55, 2109);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (27, '2022-06-10', '2022-06-14', 2, 5, 2, 56, 5208);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (28, '2022-07-13', '2022-07-18', 2, 3, 2, 57, 3200);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (29, '2022-06-24', '2022-06-31', 3, 2, 4, 58, 2304);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (30, '2022-07-09', '2022-07-10', 2, 5, 2, 62, 5205);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (31, '2022-07-12', '2022-07-23', 1, 2, 1, 64, 2101);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (32, '2022-06-20', '2022-07-07', 3, 2, 3, 66, 2303);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (33, '2022-07-10', '2022-07-16', 2, 2, 2, 68, 2202);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (34, '2022-07-04', '2022-07-12', 3, 1, 5, 70, 1303);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (35, '2022-06-08', '2022-06-11', 2, 5, 2, 76, 5206);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (36, '2022-06-17', '2022-06-20', 3, 2, 4, 77, 2301);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (37, '2022-06-06', '2022-06-12', 2, 1, 2, 81, 1208);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (38, '2022-07-13', '2022-07-18', 3, 3, 2, 83, 3304);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (39, '2022-07-16', '2022-07-29', 1, 4, 1, 86, 4104);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (40, '2022-07-19', '2022-07-25', 2, 1, 2, 88, 1207);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (41, '2022-07-08', '2022-07-15', 3, 1, 3, 89, 1302);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (42, '2022-07-13', '2022-07-14', 1, 2, 1, 91, 2100);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (43, '2022-06-04', '2022-06-10', 3, 5, 2, 92, 5301);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (44, '2022-07-01', '2022-07-04', 3, 2, 2, 94, 2300);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (45, '2022-07-03', '2022-07-07', 1, 5, 1, 96, 5108);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (46, '2022-06-27', '2022-07-08', 2, 3, 2, 98, 3208);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (47, '2022-06-05', '2022-06-17', 1, 1, 1, 99, 1101);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (48, '2022-06-08', '2022-06-18', 1, 4, 1, 100, 4107);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (49, '2022-06-30', '2022-07-10', 1, 4, 1, 102, 4105);
INSERT INTO reservation (Reservation_ID, Check_In, Check_Out, Room_ID, Hotel_ID, Number_Of_Guests, Guest_ID, Room_Number) VALUES (50, '2022-07-13', '2022-07-20', 3, 3, 3, 103, 3303);

-- Table: room
CREATE TABLE room (Room_ID INTEGER PRIMARY KEY NOT NULL, Room_Type VARCHAR (255), Room_Capacity INTEGER (255), Room_Amount INTEGER (255));
INSERT INTO room (Room_ID, Room_Type, Room_Capacity, Room_Amount) VALUES (1, 'Single', 1, 10);
INSERT INTO room (Room_ID, Room_Type, Room_Capacity, Room_Amount) VALUES (2, 'Double', 2, 15);
INSERT INTO room (Room_ID, Room_Type, Room_Capacity, Room_Amount) VALUES (3, 'Suite', 5, 10);

-- Table: room_location
CREATE TABLE room_location (Room_ID INTEGER, Hotel_ID VARCHAR, Room_Number INTEGER PRIMARY KEY);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1100);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1101);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1102);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1103);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1104);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1105);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1106);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1107);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1108);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '1', 1109);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1200);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1201);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1202);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1203);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1204);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1205);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1206);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1207);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1208);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1209);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1210);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1211);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1212);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1213);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '1', 1214);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '1', 1300);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '1', 1301);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '1', 1302);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '1', 1303);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '1', 1304);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2100);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2101);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2102);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2103);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2104);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2105);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2106);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2107);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2108);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '2', 2109);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2200);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2201);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2202);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2203);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2204);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2205);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2206);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2207);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2208);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2209);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2210);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2211);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2212);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2213);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '2', 2214);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '2', 2300);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '2', 2301);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '2', 2302);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '2', 2303);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '2', 2304);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3100);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3101);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3102);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3103);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3104);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3105);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3106);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3107);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3108);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '3', 3109);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3200);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3201);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3202);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3203);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3204);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3205);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3206);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3207);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3208);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3209);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3210);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3211);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3212);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3213);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '3', 3214);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '3', 3300);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '3', 3301);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '3', 3302);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '3', 3303);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '3', 3304);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4100);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4101);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4102);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4103);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4104);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4105);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4106);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4107);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4108);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '4', 4109);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4200);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4201);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4202);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4203);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4204);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4205);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4206);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4207);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4208);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4209);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4210);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4211);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4212);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4213);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '4', 4214);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '4', 4300);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '4', 4301);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '4', 4302);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '4', 4303);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '4', 4304);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5100);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5101);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5102);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5103);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5104);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5105);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5106);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5107);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5108);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (1, '5', 5109);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5200);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5201);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5202);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5203);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5204);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5205);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5206);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5207);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5208);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5209);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5210);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5211);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5212);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5213);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (2, '5', 5214);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '5', 5300);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '5', 5301);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '5', 5302);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '5', 5303);
INSERT INTO room_location (Room_ID, Hotel_ID, Room_Number) VALUES (3, '5', 5304);

-- View: bookroom
CREATE VIEW bookroom AS SELECT room_location.room_Number FROM room_location 
LEFT JOIN reservation ON room_location.Room_Number = reservation.Room_Number
and reservation.Check_Out >= '2022-06-25' AND reservation.Check_In <= '2022-07-18'
WHERE room_location.Hotel_ID = 2 AND room_location.Room_ID = 2
and reservation.Reservation_ID IS NULL;

-- View: describecompany
CREATE VIEW describecompany AS SELECT First_Name, Last_Name, Phone_Number, Email_Adress, Date_Of_Birth FROM guest
WHERE Reservation_ID = 5;

-- View: getallguests
CREATE VIEW getallguests AS SELECT * FROM guest;

-- View: listfacilities
CREATE VIEW listfacilities AS SELECT facility.Facility_Name AS 'Name of facility',
       hotel_facilities.Hotel_Facitilies_Name AS 'Type of facility',
       hotel.Hotel_Name AS 'Hotel name'
  FROM facility
       INNER JOIN
       hotel ON facility.Hotel_ID = hotel.Hotel_ID
       INNER JOIN
       hotel_facilities ON facility.Hotel_Facilities_ID = hotel_facilities.Hotel_Facilities_ID
 WHERE hotel.Hotel_ID = 1;

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
